//ram brava flores zero nokk iana dokka sledge thatcher lion deimos
//tubarao pulse kaid bandit mozzie ela azami warden aruni castle alibi
//stnd, qp, rk

var filt = ["kvikk","sztend","tryhard"];

function swiccs()
{
    document.addEventListener('click',function(kattint){
        kattinta = kattint.target.id;
        var ezmi = document.getElementById(kattinta);
        var valami = ezmi.id;
        var url = valami+".html";
    
        window.location.href = url;
        
    });
}

  function szuro() 
{
    var pipalva = document.querySelectorAll('input[type="checkbox"]');
    var valami = document.querySelectorAll('.szurok div');
    var mindaktiv = true;
    
    //megnézem melyik checkbox van bepipálva
    pipalva.forEach(function(checkbox) 
    {
      if (checkbox.checked) {
        mindaktiv = false;
      }
    });
    
    valami.forEach(function(item) 
    {
      if (mindaktiv) 
      {
        item.style.display = 'block';
      }

      else 
      {
        var lat = false;
        pipalva.forEach(function(checkbox) 
        {
          if (checkbox.checked && item.dataset.category == checkbox.id) 
          {
            lat = true;
          }
        });
        if (lat) 
        {
          item.style.display = 'block';
        } 
        else 
        {
          item.style.display = 'none';
        }
      }
    });
  }